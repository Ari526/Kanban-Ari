# Video tutorial

    https://youtu.be/AL7IJVhuGeA

# Reference

    - Create react app: https://create-react-app.dev/
    - SASS: https://sass-lang.com/
    - Boxicons: https://boxicons.com/
    - Google font: https://fonts.google.com/
    - React beautiful dnd: https://github.com/atlassian/react-beautiful-dnd/

# Preview

!["React Draggable Kanban Board"](https://user-images.githubusercontent.com/67447840/155845190-bd85601d-d2a0-4419-82bf-b8361f33075a.gif "React Draggable Kanban Board")